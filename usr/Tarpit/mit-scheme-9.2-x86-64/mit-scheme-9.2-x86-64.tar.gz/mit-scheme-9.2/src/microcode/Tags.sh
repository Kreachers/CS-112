#!/bin/sh
#
# Utility to make TAGS file for the MIT/GNU Scheme MICROCODE build
# directory.  The working directory must be the build directory.

make tags
